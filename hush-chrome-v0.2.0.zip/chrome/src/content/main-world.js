(function(){"use strict";const I=`
:host {
  position: fixed;
  z-index: 2147483647;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}

.hush-widget {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 10px;
  padding: 8px 14px;
  background: #06060a;
  border-radius: 14px;
  border: 1px solid rgba(0, 240, 255, 0.12);
  box-shadow:
    0 4px 24px rgba(0, 0, 0, 0.6),
    0 0 0 1px rgba(0, 240, 255, 0.06),
    inset 0 1px 0 rgba(255, 255, 255, 0.04);
  cursor: grab;
  user-select: none;
}

.hush-widget.dragging {
  cursor: grabbing;
  opacity: 0.9;
}

.power-btn {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 2px solid #00f0ff;
  background: transparent;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  box-shadow:
    0 0 8px rgba(0, 240, 255, 0.4),
    inset 0 0 8px rgba(0, 240, 255, 0.1);
  transition: box-shadow 0.2s, border-color 0.2s;
}

.power-btn:hover {
  box-shadow:
    0 0 14px rgba(0, 240, 255, 0.6),
    inset 0 0 12px rgba(0, 240, 255, 0.15);
}

.power-btn.off {
  border-color: #4a4a5a;
  box-shadow: none;
}

.power-btn.off:hover {
  border-color: #6a6a7a;
  box-shadow: none;
}

.power-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #00f0ff;
  box-shadow:
    0 0 6px rgba(0, 240, 255, 0.8),
    0 0 12px rgba(0, 240, 255, 0.4);
  transition: background 0.2s, box-shadow 0.2s;
}

.power-btn.off .power-dot {
  background: #4a4a5a;
  box-shadow: none;
}

.info {
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.title {
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 1.5px;
  color: #e8e8ed;
  line-height: 1;
  text-transform: uppercase;
}

.stats {
  font-size: 10px;
  font-family: "JetBrains Mono", "Fira Mono", "Consolas", monospace;
  color: #00ff88;
  line-height: 1;
  transition: color 0.2s;
}

.stats.off {
  color: #4a4a5a;
}

.close-btn {
  width: 22px;
  height: 22px;
  border-radius: 6px;
  border: none;
  background: rgba(255, 255, 255, 0.06);
  color: #6a6a7a;
  font-size: 13px;
  line-height: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  transition: background 0.15s, color 0.15s;
  margin-left: 2px;
}

.close-btn:hover {
  background: rgba(255, 255, 255, 0.12);
  color: #c8c8d4;
}
`;let a=null,l=null,c=null;function N(e){if(a)return;a=document.createElement("hush-widget"),a.style.left=`${e.x}px`,a.style.top=`${e.y}px`;const t=a.attachShadow({mode:"closed"}),n=document.createElement("style");n.textContent=I,t.appendChild(n);const i=document.createElement("div");i.className="hush-widget",l=document.createElement("button"),l.className="power-btn",l.setAttribute("aria-label","Toggle HUSH noise cancellation");const E=document.createElement("div");E.className="power-dot",l.appendChild(E);const v=document.createElement("div");v.className="info";const y=document.createElement("div");y.className="title",y.textContent="HUSH",c=document.createElement("div"),c.className="stats",c.id="hush-stats",c.textContent="initializing…",v.appendChild(y),v.appendChild(c);const m=document.createElement("button");m.className="close-btn",m.setAttribute("aria-label","Close HUSH widget"),m.textContent="✕",i.appendChild(l),i.appendChild(v),i.appendChild(m),t.appendChild(i),document.body.appendChild(a);let w=!1,C=0,S=0;i.addEventListener("mousedown",s=>{s.target===l||s.target===m||s.target===E||(w=!0,C=s.clientX-a.getBoundingClientRect().left,S=s.clientY-a.getBoundingClientRect().top,i.classList.add("dragging"),s.preventDefault())}),document.addEventListener("mousemove",s=>{if(!w||!a)return;const k=s.clientX-C,H=s.clientY-S;a.style.left=`${k}px`,a.style.top=`${H}px`}),document.addEventListener("mouseup",s=>{if(!w||!a)return;w=!1,i.classList.remove("dragging");const k=s.clientX-C,H=s.clientY-S;document.documentElement.dispatchEvent(new CustomEvent("hush:save-widget-pos",{detail:{x:k,y:H}}))}),l.addEventListener("click",()=>{document.documentElement.dispatchEvent(new CustomEvent("hush:widget-toggle"))}),m.addEventListener("click",()=>{document.documentElement.dispatchEvent(new CustomEvent("hush:widget-close"))})}function M(){a&&(a.remove(),a=null),l=null,c=null}function U(e,t,n){!c||!l||(n?(c.textContent=`${e} dB · ${t}ms`,c.classList.remove("off"),l.classList.remove("off")):(c.textContent="OFF",c.classList.add("off"),l.classList.add("off")))}let o={enabled:!0,strength:75,monitor:!1,disabledSites:[],preferredDeviceId:"",widgetPinned:!1,widgetPosition:{x:20,y:20}};try{const e=document.documentElement.dataset.hushState;e&&Object.assign(o,JSON.parse(e))}catch{}document.documentElement.addEventListener("hush:state",(e=>{const t={...o};if(Object.assign(o,e.detail),x(),typeof e.detail.monitor=="boolean"&&e.detail.monitor!==t.monitor&&L(e.detail.monitor),typeof e.detail.widgetPinned=="boolean")if(e.detail.widgetPinned){const n=e.detail.widgetPosition||{x:20,y:20};N(n)}else M()})),document.documentElement.addEventListener("hush:params",(e=>{const t=e.detail;typeof t.enabled=="boolean"&&(o.enabled=t.enabled),typeof t.strength=="number"&&(o.strength=t.strength),typeof t.monitor=="boolean"&&L(t.monitor),x()}));let r=null,d=null,b=null,p=null,f=!1,g=!1,u=null,h=!1;function x(){d==null||d.port.postMessage({type:"params",enabled:o.enabled,strength:o.strength})}function W(){return o.disabledSites.includes(window.location.hostname)}function P(){return document.documentElement.dataset.hushWorkletUrl}function L(e){if(!(!d||!r)){if(e&&!h)u=r.createChannelMerger(2),d.connect(u,0,0),d.connect(u,0,1),u.connect(r.destination),h=!0,console.log("[HUSH] Monitor ON — both ears");else if(!e&&h){if(u){try{d.disconnect(u)}catch{}try{u.disconnect()}catch{}u=null}h=!1,console.log("[HUSH] Monitor OFF")}}}async function D(){if(f)return!0;if(g)return new Promise(t=>{const n=setInterval(()=>{(f||!g)&&(clearInterval(n),t(f))},50)});const e=P();if(!e)return!1;g=!0;try{return r=new AudioContext({sampleRate:48e3}),await r.audioWorklet.addModule(e),d=new AudioWorkletNode(r,"noise-processor"),d.port.postMessage({type:"params",enabled:o.enabled,strength:o.strength}),d.port.onmessage=t=>{t.data.type==="metrics"?(document.documentElement.dispatchEvent(new CustomEvent("hush:metrics",{detail:t.data})),U(t.data.reduction,t.data.latencyMs,o.enabled)):t.data.type==="ready"?console.log("[HUSH] RNNoise WASM loaded, processing active"):t.data.type==="error"&&console.error("[HUSH] Worklet error:",t.data.error)},p=r.createMediaStreamDestination(),d.connect(p),f=!0,g=!1,console.log("[HUSH] Audio pipeline pre-initialized"),!0}catch(t){return console.error("[HUSH] Failed to pre-initialize pipeline:",t),g=!1,!1}}document.documentElement.addEventListener("hush:widget-toggle",()=>{o.enabled=!o.enabled,x(),document.documentElement.dispatchEvent(new CustomEvent("hush:save-state",{detail:{enabled:o.enabled}})),U(0,0,o.enabled)}),document.documentElement.addEventListener("hush:widget-close",()=>{M(),document.documentElement.dispatchEvent(new CustomEvent("hush:save-state",{detail:{widgetPinned:!1}}))}),document.documentElement.addEventListener("hush:save-widget-pos",(e=>{document.documentElement.dispatchEvent(new CustomEvent("hush:save-state",{detail:{widgetPosition:e.detail}}))})),D();const A=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);navigator.mediaDevices.getUserMedia=async function(e){if(e!=null&&e.audio&&o.preferredDeviceId){const n=e.audio;(typeof n=="boolean"||!n.deviceId)&&(e={...e,audio:{...typeof n=="boolean"?{}:n,deviceId:{ideal:o.preferredDeviceId}}})}const t=await A(e);if(e!=null&&e.audio){const n=t.getAudioTracks()[0];if(n){const i=n.getSettings().deviceId;i&&i!==o.preferredDeviceId&&(o.preferredDeviceId=i,document.documentElement.dispatchEvent(new CustomEvent("hush:save-device",{detail:{deviceId:i}})))}}if(!(e!=null&&e.audio)||!o.enabled||W()||!f&&!await D())return t;try{if(r.state==="suspended"&&await r.resume(),b)try{b.disconnect()}catch{}if(b=r.createMediaStreamSource(t),b.connect(d),p)try{d.disconnect(p)}catch{}if(p=r.createMediaStreamDestination(),d.connect(p),h&&u){try{u.disconnect()}catch{}u.connect(r.destination)}const n=p.stream;for(const i of t.getVideoTracks())n.addTrack(i);return document.documentElement.dispatchEvent(new CustomEvent("hush:status",{detail:{type:"status",active:!0,domain:window.location.hostname}})),console.log("[HUSH] Active on",window.location.hostname),n}catch(n){return console.warn("[HUSH] Failed:",n),t}},console.log("[HUSH] getUserMedia hijack installed")})();
